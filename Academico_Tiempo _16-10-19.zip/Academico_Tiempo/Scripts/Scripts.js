function ingresarAplicacion(seleccionarPagina) { // Función para hacer el envio de la página.

    if (seleccionarPagina === 'Login') {
    
        window.location.href = "UA-Solicitud-Personal.html";

    } else if (seleccionarPagina === 'Inicio') {

        window.location.href = "UA-Solicitud-Personal.html";

    } else if (seleccionarPagina === 'UA-Solicita') {

        window.location.href = "RH-Revision-Solicitud.html";

    } else if (seleccionarPagina === 'Rechazo') {

        window.location.href = "UA-Solicitud-Personal.html";

    } else if (seleccionarPagina === 'SolicitudAprobada') {

        window.location.href = "RH-PublicarConvocatoria.html";

    } else if (seleccionarPagina === 'RecepcionInformacionCandidatos') {

        window.location.href = "UA-Recepcion-Info-Candidatos.html";
    }

}

function fechaIngresoSolicitud() { // Funcion para mostrar la fecha y hora y darle formato

    var fechaActual = new Date();
    var anio = fechaActual.getFullYear();
    var mes = fechaActual.getMonth() + 1;
    var dia = fechaActual.getDate();

    var hora = fechaActual.getHours();
    var minutos = fechaActual.getMinutes();
    var segundos = fechaActual.getSeconds();

    var formatoTiempo = '' + ((hora > 12) ? hora - 12 : hora);

    if (hora == 0) 
        formatoTiempo = '12';
        formatoTiempo += ((minutos < 10) ? ':0' : ':') + minutos;
        formatoTiempo += ((segundos < 10) ? ':0' : ':') + segundos;
        formatoTiempo += (hora >= 12) ? ' P.M.' : ' A.M.'; 
    
    var fechaCompleta = anio + " / " + mes + " / " + dia + " - " + formatoTiempo;

    document.getElementById('horaFecha').innerHTML = fechaCompleta;
}

function limpiarParametros() { // Función para ocultar los elementos mostrados en el área de la solicitud.

    document.getElementById('tiposSolicitudes').style.display = 'none';
    document.getElementById('datosSolicitud').style.display = 'none';
    document.getElementById('tipoPlazaSolicitada').value;

    //console.log(valorControl);

}

function contenidoOpcionMenu(nombrePagina) { // Función para ocucltar y mostrar el contenido asociado a las opciones del menu.
/* 
    let pagina = ontenerNombrePagina();
    let nombrePagina = pagina.substring(0, pagina.length - 5);
  */   

    switch (nombrePagina) {

        case 'Solicitudes':

            document.getElementById('tiposSolicitudes').style.display = 'block';
            document.getElementById('datosSolicitud').style.display = 'none';

        break;
        /* RH-Revision-Solicitud */
        case 'InforamcionSolicitud':

            document.getElementById('datosSolicitud').style.display = 'block';
            document.getElementById('tiposSolicitudes').style.display = 'none';

        break;

        case 'SolicitudAcademicoTiempo':

            document.getElementById('datosSolicitud').style.display = 'block';
            document.getElementById('tiposSolicitudes').style.display = 'none';

        break;

        case 'contactoCandidatos':

            document.getElementById('controlContactoCandidatos').style.display = 'block';
            document.getElementById('datosSolicitud').style.display = 'none';
            document.getElementById('tiposSolicitudes').style.display = 'none';
        
        break;
        
        default:

    }

}

function guardarValores() { // Funcion para guardar en session la información capturada en la solicitud.

    var plazaSeleccionada = document.getElementById('tipoPlazaSolicitada').value;
    var nombrePersonaSust = document.getElementById('personaSustituida').value;
    var motivoSust = document.getElementById('motivoSustitucion').value;
    var fechaAproxContratacion = document.getElementById('fechaTentativaContratacion').value;
    var numeroSolicitud = document.getElementById('numeroSolicitudGenerado').value;
    
    window.sessionStorage.setItem('Plaza', plazaSeleccionada);
    window.sessionStorage.setItem('Persona', nombrePersonaSust);
    window.sessionStorage.setItem('Motivo', motivoSust);
    window.sessionStorage.setItem('Fecha', fechaAproxContratacion);
    window.sessionStorage.setItem('NumSolicitud', numeroSolicitud);

}

function validarCamposRequeridos() { // Función para mostrar u ocultar los campos requeridos en caso de Sustitución o Suplencia.

    var plaza = document.getElementById('tipoPlazaSolicitada').value;
    
    if (plaza === 'Sustitución' || plaza === 'Suplencia') {

        document.getElementById('personaSustituida').style.visibility = 'visible';
        document.getElementById('motivoSustitucion').style.visibility = 'visible';
        document.getElementById('lblSustituye').style.visibility = 'visible';
        document.getElementById('lblMotivo').style.visibility = 'visible';

    } else {

        document.getElementById('personaSustituida').style.visibility = 'hidden';
        document.getElementById('motivoSustitucion').style.visibility = 'hidden';
        document.getElementById('lblSustituye').style.visibility = 'hidden';
        document.getElementById('lblMotivo').style.visibility = 'hidden';
        
    }

}

function mostrarInformacionSolicitud() { // Función para guardar en sesión la información de la persona la que se sustituye

    document.getElementById('Plaza').innerHTML = window.sessionStorage.getItem('Plaza');
    document.getElementById('datoSustituye').innerHTML = window.sessionStorage.getItem('Persona');
    document.getElementById('datoMotivo').innerHTML = window.sessionStorage.getItem('Motivo');
    document.getElementById('fechaSugerida').innerHTML = window.sessionStorage.getItem('Fecha');
    document.getElementById('numeroSolicitud').innerHTML = window.sessionStorage.getItem('NumSolicitud');
        
}

function mostrarMotivosRechazo(estatusAprobacion) { // Función para mostrar el control para los motivos de rechazo.

    var guardarMotivoRechazo = document.getElementById('motivoRechazo').value;

    if(estatusAprobacion === 'Aprobar') {

        document.getElementById('motivoRechazo').style.visibility = 'hidden';
        document.getElementById('botonEnviar').style.visibility = 'visible';
        document.getElementById('botonRechazo').style.visibility = 'hidden';
        document.getElementById('motivoRechazoLbl').style.visibility = 'hidden';

    } else {
        
        document.getElementById('motivoRechazoLbl').style.visibility = 'visible';
        document.getElementById('motivoRechazo').style.visibility = 'visible';
        document.getElementById('botonRechazo').style.visibility = 'visible';
        document.getElementById('botonEnviar').style.visibility = 'hidden';
        window.sessionStorage.setItem('MotivoRech', guardarMotivoRechazo);
    }

}

function guardarInformacion() { // Función para guardar en la sesión la inforamción del candidato.
    var candidatoNombre = document.getElementById('nombreCandidato').value;
    var candidatoEstatus = document.getElementById('estatusCandidato').value;
    var citaCandidato = document.getElementById('fechaCitaCandidato').value;

    window.sessionStorage.setItem('Candidato', candidatoNombre);
    window.sessionStorage.setItem('Estatus', candidatoEstatus);
    window.sessionStorage.setItem('Cita', citaCandidato);
    
}

function agregarCandidatos() { // Función para agregar la inforamción del candidato a la tabla de Registro.

    var table = document.getElementById('tablaCandidatos');
    var row = table.insertRow(-1);
    var celda1 = row.insertCell(0); 
    var celda2 = row.insertCell(1);
    var celda3 = row.insertCell(2);

    celda1.innerHTML = window.sessionStorage.getItem('Candidato');
    celda2.innerHTML = window.sessionStorage.getItem('Estatus'); 
    celda3.innerHTML = window.sessionStorage.getItem('Cita');

}

function generarNumeroAleatorio() { // Funcion para generar un numero aleatorio de 6 posiciones.
	
    var numSolicitud = document.getElementById('numeroSolicitudGenerado');
    
    numSolicitud.value = (numSolicitud.innerHTML = Math.floor((Math.random() * 1000000 + 1)));
    
    window.sessionStorage.setItem("NumeroSolicitudGenerado", numSolicitud.innerHTML);
   
}

function ontenerNombrePagina() {

    var pathCompleto = window.location.pathname;
    var nombrePagina = pathCompleto.split("/").pop();
    
    return nombrePagina;
}